/*Um Número é dito Primo se possui como divisores o número 1 e ele mesmo. Em outras 
palavras, um Número Primo possui dois divisores de 1 até ele.
Faça um programa que mostre se um determinado número inteiro, lido pelo teclado, é 
Primo.
Um Número é dito Perfeito se a soma de seus divisores menores que ele é igual a ele. Por 
exemplo, o número 6 possui os  divisores 1, 2 e 3, cuja soma é igual a 6.
Faça um programa que liste os números perfeitos de 1 a 1000.*/


using System;

class Program {
  public static void Main (string[] args) {
    int n,cont=0; 
    
    Console.WriteLine ("Digite um numero: ");
    n = int.Parse(Console.ReadLine());

    for(int i=1;i<=n;i++){

      if(n%i == 0){
        cont++;
      }
      
    }

    if(cont==2){
      Console.WriteLine ("O numero: "+n+" é primo");
    }
      else{
        Console.WriteLine ("O numero: "+n+" não é primo");
      }

    int num,u,soma1=0;

    for(num=1;num<=1000;num++){
      
      for(u=1;u<num;u++){
      
        if(num%u == 0){
          soma1 = soma1 + u;
        }
      }
      if(num==soma1){
        Console.WriteLine ("O numero: "+num+" é perfeito");
        }

        soma1=0;
    }
  }
}